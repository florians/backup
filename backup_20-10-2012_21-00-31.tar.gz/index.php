<?
	include_once "include/head.php";
	include_once "include/banner.php";
	include_once "include/navi.php";
	include_once "include/content.php";
	include_once "include/footer.php";
?>