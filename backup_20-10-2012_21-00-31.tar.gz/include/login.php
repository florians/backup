<?php
	include "class/mysql.php";
	session_start();
	$user = Database::getInstance()->select("user",'*',"username = '".$_POST['username']."' AND password = '".$_POST['password']."'");

	if(isset($_POST['sendLogin'])){	
		if($_POST['username'] == $user[0]['username'] && $_POST['password'] == $user[0]['password']){
			session_start();
			$_SESSION['username'] = $user[0]['username'];
			$_SESSION['userid'] = $user[0]['id'];
			header("Location:../index.php?id=Home");
		}
	}
	if(isset($_POST["sendLogout"])){
		session_destroy();
		header("Location:../index.php?id=Home");
	}
?>
