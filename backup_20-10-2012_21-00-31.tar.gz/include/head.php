<?php
	include "include/class/mysql.php";
	$db = Database::getInstance();
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>My Test Website</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
		<link rel="stylesheet/less" type="text/css" href="css/styles.less" />
		<link rel="stylesheet" type="text/css" href="css/ui-darkness/jquery-ui-1.8.23.custom.css" />
		<script type="text/javascript">
			var less = { env: "development" };
		</script>
		<link rel="icon" type="image/png" href="images/favicon.png" />
		<script src="script/less.js" type="text/javascript"></script>
		<script src="script/jquery-1.8.0.min.js" type="text/javascript"></script>
		<script src="script/jquery-ui-1.8.23.custom.min.js" type="text/javascript"></script>
		<script src="script/basic-jquery-slider.js" type="text/javascript"></script>
		<script src="script/subnavi.js" type="text/javascript"></script>
		
		<!-- Fancybox Start -->
		<script type="text/javascript" src="script/fancybox/jquery.fancybox.js?v=2.1.2"></script>
		<script type="text/javascript" src="script/fancybox/jquery.fancybox-buttons.js?v=1.0.5"></script>
		<script type="text/javascript" src="script/fancybox/jquery.fancybox-media.js?v=1.0.4"></script>
		<script type="text/javascript" src="script/fancybox/jquery.fancybox-thumbs.js?v=1.0.7"></script>
		<script type="text/javascript" src="script/fancybox/jquery.mousewheel-3.0.6.pack.js"></script>
		<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.2" media="screen" />
		<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox-buttons.css?v=1.0.5" />
		<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox-thumbs.css?v=1.0.7" />
		<!-- Fancybox Stop -->

		<script type="text/javascript">
			jQuery(document).ready(function() {
				jQuery('#banner').bjqs({
					'animation' : 'fade',
					'width' : 1200,
					'height' : 300,
					'animationDuration': 10000,
					'showMarkers' : false,
					'showControls' : false,
					'centerMarkers' : false
				});
				jQuery(document).keydown(function (e) {
					if (e.keyCode == 107) {
						jQuery(".login").show();
						jQuery("#bg").css('display', 'block');
					}
				});
				jQuery("#bg").click(function (e) {
						jQuery(".login").hide();
						jQuery("#bg").css('display', 'none');
				});
				jQuery( ".accordion" ).accordion({collapsible:true,active:false,autoHeight:false});
				jQuery( ".accordion1" ).accordion({collapsible:true,active:false,autoHeight:false});
				
				
				// Fancybox
				$('.fancybox-thumbs').fancybox({
					prevEffect : 'none',
					nextEffect : 'none',

					closeBtn  : true,
					arrows    : true,
					nextClick : true,

					helpers : {
						thumbs : {
							width  : 100,
							height : 50
						}
					}
				});
			});
		</script>
	</head>
	<body>
		<?php
		if($_SESSION['userid'] == ''){
		?>
			<div class="login">
				<form action="include/login.php" method="post">
					<input name="username" type="text" value="Benutzername" onFocus="if(this.value=='Benutzername')this.value=''" onblur="if(this.value=='')this.value='Benutzername'"><br />
					<input name="password" type="password" value="Passwort" onFocus="if(this.value=='Passwort') this.value=''" onblur="if(this.value=='') this.value='Passwort'"><br />
					<input name="sendLogin" type="submit" value=" Login ">
				</form>
			</div>
		<?php
		}else{
		?>
			<div class="login">
				<form action="include/login.php" method="post">
					Hallo <?php echo $_SESSION['username']; ?>
					<input name="sendLogout" type="submit" value=" Logout ">
				</form>
				<a href="index.php?id=config">Config</a>
			</div>
		<?php
		}
		?>
		<div id="wrapper">