			<div id="contentmargin">
				<div id="content">
					<?php
						switch ($_GET['id']){
							case 'Home':
							case '':
								include_once 'id/home.php';
							break;
							case 'config':
								include_once 'id/config.php';
							break;
							case 'Upload':
								include_once 'id/upload.php';
							break;
							case 'a' || 'b':
								include_once 'id/new_site.php';
							break;
						}
					?>
				</div>
			</div>