			<div id="pagemargin">
				<div id="banner">
					<ul class="slide">
						<li class="slider"><img src="images/pic.jpg" alt="pic1" /></li>
						<li class="slider"><img src="images/pic2.jpg" alt="pic1" /></li>
						<!--<li id="slider"><img src="images/pic3.jpg" alt="pic1" /></li>-->
					</ul>
				</div>
			</div>
			
			