<?php
	$nav = Database::getInstance()->select("navigation","id","name = ".$_GET['id']);
	$user = Database::getInstance()->select("user");
	
	foreach($user as $username){
		$content = Database::getInstance()->select("content_table","*","content_nav_id".$nav['id']." AND content_user_id=".$username['id']);
		if(count($content)){
		?>
		<div class="accordion">
			<div class="accordion_header"><a href="#"><?php echo $username['username']; ?></a></div>
			<div class="accordion_content">
				<div>
					<?php
					for($i = 1;$i<=3;$i++){
						$cont_name = array("","Bilder","Video","Audio");
						$content_entry = Database::getInstance()->select("content_table","*","content_nav_id".$nav['id']." AND content_user_id=".$username['id']." AND content_type='".$i."'");
						if(count($content_entry)){
						
						?>
						<div class="accordion1">
							<div class="accordion_header"><a href="#"><?php echo $cont_name[$i] ?></a></div>
							<div class="accordion_content">
								<div>
								<?php
								foreach($content_entry as $images){
								?>
									<div class="content_images">
										<a class="fancybox-thumbs" data-fancybox-group="thumb" href="<?php echo $images['content_filepath_ori'] ?>"><img src="include/img.php?img=<?php echo $images['content_filepath_ori'] ?>" alt="<?php echo $images['content_name'];?>" /></a>
									</div>
								<?php
								}
								?>
								</div>
							</div>
						</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</div>
		<?php
		}
	}
?>