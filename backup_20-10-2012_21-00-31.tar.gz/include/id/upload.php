<?php
	session_start();
	
	if(isset($_POST['upload_submit'])){
		$target_path = "uploads/";
		//$target_path = $target_path . basename( $_FILES['upload_file']['name']);
		$content = Database::getInstance()->select("content_table");
		
		$target_path = $target_path . $_SESSION['username'].'_'.count($content).'.jpg'; 
		Database::getInstance()->insert('content_table',array(2,$_POST['upload_name'],1,$target_path,1,$_POST['upload_name']),'content_nav_id,content_text,content_type,content_filepath_ori,content_user_id,content_name');
		
		if(move_uploaded_file($_FILES['upload_file']['tmp_name'], $target_path)) {
			echo "The file ".  basename( $_FILES['upload_file']['name']). 
			" has been uploaded";
		} else{
			echo "There was an error uploading the file, please try again!";
		}
	}
?>
	<form enctype="multipart/form-data" action="index.php?id=Upload" method="post">
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="upload_name" /></td>
			</tr>
			<tr>
				<td colspan="2"><input type="file" name="upload_file" /></td>
			</tr>
			<tr>
				<td><input type="submit" name="upload_submit" /></td>
			</tr>
		</table>
	</form>
