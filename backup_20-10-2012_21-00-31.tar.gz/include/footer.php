			<div id="footermargin">
				<div id="footer">&copy; Florian Stettler</div>
			</div>
			<div id="bg"></div>
		</div>
	</body>
</html>