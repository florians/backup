jQuery(document).ready(function(){
	$("#navi_sub .subnavi").hover(function(e) {
        $(this).stop().animate({width: '150'}, 500);
		e.preventDefault();
    }, function() {
        $(this).stop().animate({ width: '50' }, 500);
		e.preventDefault();
    });
});