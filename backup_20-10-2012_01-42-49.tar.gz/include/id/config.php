<?php
	if($_SESSION['userid'] != ''){
		if($_GET['id']=="config"){
			if(isset($_POST['insertNavLink'])){
				Database::getInstance()->insert('navigation',array('',$_POST['navilink']));
				header("Location:index.php?id=config");
			}
			if(isset($_POST['changeNavLink'])){
				Database::getInstance()->update('navigation',array('name'=>$_POST['newNavName']),array('id = '.$_POST['navNameID']));
				header("Location:index.php?id=config");
			}
			if(isset($_POST['deleteNavLink'])){
				Database::getInstance()->delete('navigation','id ='.$_POST['navNameID']);
				header("Location:index.php?id=config");
			}
		?>
			<form action="index.php?id=config" method="POST">
				Navigationslink: <input type="text" name="navilink">
				<input type="submit" name="insertNavLink" value=" eintragen ">
			</form>
			<br />
			<h2>Vorhandene Navigationspunkte</h2>
		<?php
			$navigation = Database::getInstance()->select("navigation");
			$mainlink = "index.php?id=";
		foreach($navigation as $navipoint){
			?>
				<form action="index.php?id=config" method="POST">
					<?php if($navipoint['name'] == "Home" || $navipoint['name'] == "Upload"){ ?>
						<?php echo $navipoint['name']; ?>
					<? }else{ ?>
						<input type="text" value="<?php echo $navipoint['name']; ?>" name="newNavName">
						<input type="hidden" value="<?php echo $navipoint['id']; ?>" name="navNameID">
						<input type="submit" name="changeNavLink" value=" &auml;ndern ">
						<input type="submit" name="deleteNavLink" value=" delete ">
					<? } ?>
					
				</form>
			<?php 
			}
		}
	}
?>