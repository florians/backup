<?php
	$nav = Database::getInstance()->select("navigation","id","name = ".$_GET['id']);
	$user = Database::getInstance()->select("user");

	foreach($user as $username){
		$content = Database::getInstance()->select("content_table","*","content_nav_id".$nav['id']." AND content_user_id=".$username['id']);
		
		if(count($content)){
		?>
		<div class="accordion">
			<div class="accordion_header"><a href="#"><?php echo $username['username']; ?></a></div>
			<div class="accordion_content">
				<div>
					<?php
					foreach($content as $content_entry){
						switch($content_entry['content_type']){
							case 1:
								?>
								<div class="accordion1">
									<div class="accordion_header"><a href="#">Bilder</a></div>
									<div class="accordion_content">
										<div>
											<div class="content_images">
												<a class="fancybox-thumbs" data-fancybox-group="thumb" href="<?php echo $content_entry['content_filepath_ori'] ?>"><img src="include/img.php?img=<?php echo $content_entry['content_filepath_ori'] ?>" alt="<?php echo $content_entry['content_name'];?>" /></a>
											</div>		
										</div>
									</div>
								</div>
								<?php
							break;
							case 2;
								?>
								<div class="accordion1">
									<div class="accordion_header"><a href="#">Video</a></div>
									<div class="accordion_content">
										<div>
											<div class="content_images">
												<a class="fancybox-thumbs" data-fancybox-group="thumb" href="<?php echo $content_entry['content_filepath_ori'] ?>"><img src="include/img.php?img=<?php echo $content_entry['content_filepath_ori'] ?>" alt="<?php echo $content_entry['content_name'];?>" /></a>
											</div>		
										</div>
									</div>
								</div>
								<?php
							break;
							case 3;
							break;
						}
					}	
					?>							
				</div>
			</div>
		</div>
		<?php
		}
	}
?>