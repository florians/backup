			<div id="navimargin">
				<div id="navi">
					<div id="navipoints">
						<?
							$navigation = Database::getInstance()->select("navigation");
							$mainlink = "index.php?id=";

							foreach($navigation as $navipoint){
								if($_GET['id'] == "" && $navipoint['name'] == 'Home' || $_GET['id'] == $navipoint['name']){
									echo "<a class='active' href='".$mainlink.$navipoint['name']."'>".$navipoint['name']."</a>";
								}else{
									echo "<a href='".$mainlink.$navipoint['name']."'>".$navipoint['name']."</a>";
								}
							}
						?>
					</div>
				</div>
			</div>
			<!--<div id="navi_sub">
				<?	
					foreach($navigation as $navipoint){
						if($_GET['id'] == "" && $navipoint['name'] == 'Home' || $_GET['id'] == $navipoint['name']){
							?>
							<div class="subnavi">
								<a class='active' href='<?= $mainlink.$navipoint['name'] ?>'><?= $navipoint['name']?></a>
							</div>
							<?
						}else{
							?>
							<div class="subnavi">
								<a href='<?= $mainlink.$navipoint['name'] ?>'><?= $navipoint['name']?></a>
							</div>
							<?
						}
					}						
				?>
			</div>-->