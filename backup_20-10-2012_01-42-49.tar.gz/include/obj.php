<?php
	$db = new mysqli("localhost","thalarionsql3","510d8fe8","thalarionsql3");
	function selectNavi(){
		$naviselect = "SELECT * FROM navigation";
		print_r($naviselect);
		$navigation = $db->query($naviselect);
		print_r($navigation);
		while($tmp =  $navigation->fetch_assoc()){
			$navi[] = $tmp;
		}
		return $navi;
	}
?>