<?php
	header('Content-type: image/jpeg');
	$url='http://'.$_SERVER['SERVER_NAME'].'/'.$_GET['img'];

	$im = new imagick($url);
	$im->thumbnailImage(200, null);

	echo $im;

?>