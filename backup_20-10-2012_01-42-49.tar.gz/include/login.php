<?php
	include "class/mysql.php";
	session_start();
	$user = Database::getInstance()->select("user",'*',"username = '".$_POST['username']."' AND password = '".$_POST['password']."'");
	if(isset($_POST['sendLogin'])){
		if($_POST['username'] == $user['username'] && $_POST['password'] == $user['password']){
			session_start();
			$_SESSION['username'] = $user['username'];
			$_SESSION['userid'] = $user['id'];
			header("Location:../index.php?id=Home");
		}
	}
	if(isset($_POST["sendLogout"])){
		session_destroy();
		header("Location:../index.php?id=Home");
	}
?>
